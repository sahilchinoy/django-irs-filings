from django.test import TestCase
from django.core.management import call_command
from irs.models import *

class LoadTestCase(TestCase):
    def test_load_command(self):
        call_command('load', test=True)
        
        self.assertEqual(
            F8872.objects.count(),
            65)
        self.assertEqual(
            Contribution.objects.count(),
            5001)
        self.assertEqual(
            Expenditure.objects.count(),
            5001)
        self.assertEqual(
            Committee.objects.count(),
            49)

    def test_committee(self):
        #print Committee.objects.all.count()
        #self.assertGreater(Committee.objects.all.count(), 0)
        pass